package xyz.he00741098.DinoGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DinoGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
